A Pen created at CodePen.io. You can find this one at https://codepen.io/thirdastronaut/pen/mjPYNr.

 In this experiment, I set out to build a sexy, simple, interactive, and animated particle network using Canvas and JavaScript. Fully plug n' play, modular, and customisable, just drop it in any webpage.